const $ = document.querySelector.bind(document);

export default $;
export const hide = (e) => (e.style.display = 'none');
export const show = (e) => (e.style.display = 'block');
