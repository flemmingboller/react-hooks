import $ from './utils.js';
import { store, RETIREMENT_AGE_ADDED } from './store.js';
import AgeComponent from './components/age.component.js';
import MinPensionComponent from './components/min-pension.component.js';
import CalculatorHeadlineComponent from './components/calculator-headline.component.js';
import CalculationSwitcherComponent from './components/calculator-switcher.component.js';
import WishedMonthlySavingsComponent from './components/wished-monthlysavings.component.js';
import WishedPensionGoalComponent from './components/wished-pensiongoal.component.js';
import LumpsumComponent from './components/lumpsum.component.js';
import InvestmentProfileComponent from './components/investment-profile.component.js';
import RetirementAgeInput from './components/pension-age.component.js';
import BarComponent from './components/bar.component.js';
import BarHeadlineComponent from './components/bar-headline.component.js';
import { CalculationService } from './effects/calculation.effect.js';

const counterSelector = (state) => state.counter;

store.subscribe(() => {
  console.log(store.getState());
});

store.dispatch({ type: 'INITIALIZE' });

new RetirementAgeInput(store).render();

new AgeComponent(store).render();
new MinPensionComponent(store).render();
new CalculatorHeadlineComponent(store).render();
new CalculationSwitcherComponent(store).render();
new WishedMonthlySavingsComponent(store).render();
new WishedPensionGoalComponent(store).render();
new LumpsumComponent(store).render();
new InvestmentProfileComponent(store).render();
new BarComponent(store, '#lowbar', 'low').render();
new BarComponent(store, '#middlebar', 'middle').render();
new BarComponent(store, '#highbar', 'high').render();
new BarHeadlineComponent(store).render();
new CalculationService(store);
