import $ from '../utils.js';
import { store } from '../store.js';

export default class CalculatorHeadlineComponent {
  constructor(store) {
    this.store = store;
    this.store.subscribe(this.render.bind(this));
    this.el = $('#calculator-headline');
  }

  render() {
    this.el.innerHTML = store.getState().appConfiguration.calculatorHeadLine[
      store.getState().calculatorType
    ];
  }
}
