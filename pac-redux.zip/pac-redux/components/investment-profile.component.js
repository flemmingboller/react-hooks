import $ from '../utils.js';
import { store, INVESTMENT_PROFILE_ADDED } from '../store.js';

export default class InvestmentProfileComponent {
  constructor(store) {
    this.store = store;
    this.store.subscribe(this.render.bind(this));
    this.el = $('#investmentprofile');
    this.el.addEventListener('change', (e) => {
      this.store.dispatch({
        type: INVESTMENT_PROFILE_ADDED,
        payload: e.target.value,
      });
    });
  }

  render() {
    const profiles = this.store.getState().appConfiguration.investmentProfiles;
    const selectedProfile = this.store.getState().investmentProfile;
    this.el.innerHTML = profiles
      .map(
        (profile) =>
          `<option value=${profile.id} ${
            selectedProfile === profile.id ? 'selected' : ''
          }>${profile.label}</option>`
      )
      .join('');
  }
}
