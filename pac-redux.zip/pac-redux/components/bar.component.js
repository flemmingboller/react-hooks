import $ from '../utils.js';
import { store } from '../store.js';

export default class BarComponent {
  constructor(store, cssSelector, resultKey) {
    this.store = store;
    this.resultKey = resultKey;
    this.el = $(cssSelector);
    this.bar = this.el.getElementsByClassName('bar-element')[0];
    this.barLegend = this.el.getElementsByClassName('value')[0];
    store.subscribe(this.render.bind(this));
  }

  render() {
    if (
      this.store.getState().calculationResult.hasOwnProperty(this.resultKey)
    ) {
      const result = this.store.getState().calculationResult[this.resultKey];

      this.bar.style.height = (result.height || 0) + 100 + 'px';
      this.barLegend.innerHTML = result.value;
    }
  }
}
