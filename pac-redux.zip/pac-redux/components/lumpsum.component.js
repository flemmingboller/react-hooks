import $ from '../utils.js';
import { store, LUMPSUM_ADDED } from '../store.js';
import { numberFormat } from '../cleave-utils.js';

export default class LumpsumComponent {
  constructor(store) {
    this.store = store;
    this.store.subscribe(this.render.bind(this));
    this.el = $('#one-time-input');

    $('#one-time-input input').addEventListener('change', () => {
      this.store.dispatch({
        type: LUMPSUM_ADDED,
        payload: this.cleaveInput.getRawValue(),
      });
    });
    this.cleaveInput = numberFormat('#one-time-input input');
  }

  render() {}
}
