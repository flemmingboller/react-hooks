import $ from '../utils.js';
import { CALCULATOR_SWITCH } from '../store.js';

export default class CalculationSwitcherComponent {
  constructor(store) {
    this.store = store;
    Array.from($('#switchers').getElementsByTagName('a')).forEach((e) => {
      e.addEventListener('click', (e) => {
        e.preventDefault();
        const calcType = e.target.getAttribute('data-payload');
        this.store.dispatch({ type: 'CALCULATOR_SWITCH', payload: calcType });
      });
    });
  }

  render() {}
}
