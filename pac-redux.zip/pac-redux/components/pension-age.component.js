import $ from '../utils.js';
import { store, RETIREMENT_AGE_ADDED } from '../store.js';

export default class RetirementAgeInput {
  constructor(store) {
    this.store = store;
    store.subscribe(() => {
      this.render();
    });
    this.el = $('#retirementage');

    this.warning = this.el.querySelector('.retirementage-warning');
    this.input = this.el.querySelector('input');
    this.input.addEventListener('blur', (e) =>
      this.store.dispatch({
        type: RETIREMENT_AGE_ADDED,
        payload: parseInt(e.target.value),
      })
    );
  }

  // Here we can show hide relevant inputs and populate fields / value of inputs.
  // its also here we can fetch values from store.

  render() {
    this.input.value = store.getState().retirementAge;
    this.warning.style.display =
      this.store.getState().retirementAge < 62 ? 'block' : 'none';
  }
}
