import $ from '../utils.js';
import { store, MONTHLY_SAVINGS_CACULATOR } from '../store.js';
import { numberFormat } from '../cleave-utils.js';

export default class WishedMonthlySavingsComponent {
  constructor(store) {
    this.store = store;
    this.store.subscribe(this.render.bind(this));
    this.el = $('#wishedMonthlySaving');
  }

  render() {
    if (this.store.getState().calculatorType === MONTHLY_SAVINGS_CACULATOR) {
      this.el.style.display = 'none';
    } else {
      this.el.style.display = 'block';
    }
  }
}
