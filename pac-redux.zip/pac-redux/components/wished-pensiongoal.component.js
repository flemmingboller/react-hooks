import $ from '../utils.js';
import {
  store,
  WISHED_PENSION_GOAL_ADDED,
  MONTHLY_SAVINGS_CACULATOR,
} from '../store.js';
import { numberFormat } from '../cleave-utils.js';

export default class WishedPensionGoalComponent {
  constructor(store) {
    this.store = store;
    this.store.subscribe(this.render.bind(this));
    this.el = $('#wishedPensionGoal');
    this.cleaveInput = numberFormat('#wishedPensionGoal input');

    $('#wishedPensionGoal input').addEventListener('change', () => {
      this.store.dispatch({
        type: WISHED_PENSION_GOAL_ADDED,
        payload: this.cleaveInput.getRawValue(),
      });
    });
    this.cleaveInput = numberFormat('#wishedPensionGoal input');
  }

  render() {
    if (this.store.getState().calculatorType === MONTHLY_SAVINGS_CACULATOR) {
      this.el.style.display = 'block';
    } else {
      this.el.style.display = 'none';
    }
    this.cleaveInput.setRawValue(store.getState().wishedPensionGoal);
  }
}
