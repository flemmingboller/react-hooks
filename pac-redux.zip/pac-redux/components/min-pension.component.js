import $ from '../utils.js';
import { store, MINPENSION_ADDED } from '../store.js';
import { numberFormat } from '../cleave-utils.js';

export default class MinPensionComponent {
  constructor(store) {
    this.store = store;
    this.minPensionValue = numberFormat('#minpension input');

    $('#minpension input').addEventListener('change', (e) =>
      store.dispatch({
        type: MINPENSION_ADDED,
        payload: parseInt(this.minPensionValue.getRawValue()),
      })
    );
  }

  render() {
    const minpension = store.getState().minpension;
    this.minPensionValue.setRawValue(minpension == 0 ? '' : minpension);
  }
}
