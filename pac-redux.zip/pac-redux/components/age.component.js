import $ from '../utils.js';
import { store } from '../store.js';
export default class AgeComponent {
  constructor(store) {
    this.store = store;
    this.el = $('#ageInput');
    this.input = this.el.querySelector('input');
    this.input.addEventListener('change ', (e) =>
      store.dispatch({ type: 'AGE_ADDED', payload: parseInt(e.target.value) })
    );
  }

  render() {
    const age = store.getState().age;
    this.input.value = age == 0 ? '' : age;
  }
}
