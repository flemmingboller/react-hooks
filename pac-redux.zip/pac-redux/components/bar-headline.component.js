import $, { hide, show } from '../utils.js';
import {
  store,
  PENSIONGOAL_CACULATOR,
  MONTHLY_SAVINGS_CACULATOR,
} from '../store.js';

export default class BarHeadlineComponent {
  constructor(store) {
    this.store = store;
    this.store.subscribe(this.render.bind(this));
    this.el = $('.explanation-text');
    this.monthlyHeadline = this.el.getElementsByClassName(
      'monthly_component'
    )[0];
    this.pensionHeadline = this.el.getElementsByClassName(
      'pension_component'
    )[0];
    this.wealthHeadline = this.el.getElementsByClassName('wealth_component')[0];
    store.subscribe(this.render.bind(this));
  }

  render() {
    if (store.getState().calculatorType === MONTHLY_SAVINGS_CACULATOR) {
      show(this.monthlyHeadline);
      hide(this.pensionHeadline);
      hide(this.wealthHeadline);
    } else if (store.getState().calculatorType === PENSIONGOAL_CACULATOR) {
      hide(this.monthlyHeadline);
      show(this.pensionHeadline);
      hide(this.wealthHeadline);
    } else {
      hide(this.monthlyHeadline);
      hide(this.pensionHeadline);
      show(this.wealthHeadline);
    }
  }
}
