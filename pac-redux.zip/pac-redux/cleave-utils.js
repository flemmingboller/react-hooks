export const numberFormat = (selector) =>
  new Cleave(selector, {
    numeral: true,
    delimiter: '.',
    numeralDecimalMark: ',',
    numeralThousandsGroupStyle: 'thousand',
  });
