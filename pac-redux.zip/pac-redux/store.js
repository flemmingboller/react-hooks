export const MONTHLY_SAVINGS_CACULATOR = 'MONTHLY_SAVINGS_CACULATOR';
export const PENSIONGOAL_CACULATOR = 'PENSIONGOAL_CACULATOR';

export const RETIREMENT_AGE_ADDED = 'RETIREMENT_AGE_ADDED';
export const AGE_ADDED = 'AGE_ADDED';
export const MINPENSION_ADDED = 'MINPENSION_ADDED';
export const LUMPSUM_ADDED = 'LUMPSUM_ADDED';
export const INVESTMENT_PROFILE_ADDED = 'INVESTMENT_PROFILE_ADDED';
export const WISHED_PENSION_GOAL_ADDED = 'WISHED_PENSION_GOAL_ADDED';
export const CALCULATOR_SWITCH = 'CALCULATOR_SWITCH';
export const CALCULATION_DONE = 'CALCULATION_DONE';

const initialState = {
  defaultRetirementAge: 72,
  retirementAge: 0,
  minpension: 30000,
  lumpSum: 0,
  age: 0,
  inputDirty: false,
  wishedPensionGoal: null,
  calculatorType: MONTHLY_SAVINGS_CACULATOR,
  investmentProfile: 3,
  appConfiguration: {
    calculatorHeadLine: {
      MONTHLY_SAVINGS_CACULATOR:
        'Fyll i uppgifter för pensionsberäkningen (MS)',
      PENSIONGOAL_CACULATOR: 'Fyll i uppgifter för pensionsberäkningen (PENS)',
      MONTHLY_SAVINGS_CACULATOR1:
        'Fyll i uppgifter för pensionsberäkningen (LUMP)',
    },
    investmentProfiles: [
      { label: 'Defensiv', id: 0 },
      { label: 'Försiktig', id: 1 },
      { label: 'Balanserad', id: 2 },
      { label: 'Fokus Tillväxt', id: 3 },
      { label: 'Fokus Avkastning', id: 4 },
    ],
  },
  calculationResult: {},
};

function counter(state = initialState, action) {
  switch (action.type) {
    case 'INCREMENT':
      state.counter += 1;
      return state;
    case 'DECREMENT':
      state.counter -= 1;
      return state;
    case 'INITIALIZE':
      return Object.assign({}, state, {
        retirementAge: state.defaultRetirementAge,
      });
    case RETIREMENT_AGE_ADDED:
      return Object.assign({}, state, {
        retirementAge: action.payload,
        inputDirty: true,
      });
    case AGE_ADDED:
      return Object.assign({}, state, {
        age: action.payload,
        inputDirty: true,
      });
    case MINPENSION_ADDED:
      return Object.assign({}, state, {
        minpension: action.payload,
        inputDirty: true,
      });
    case CALCULATOR_SWITCH:
      return Object.assign({}, state, {
        calculatorType: action.payload,
      });
    case WISHED_PENSION_GOAL_ADDED:
      return Object.assign({}, state, {
        wishedPensionGoal: action.payload,
        inputDirty: true,
      });
    case LUMPSUM_ADDED:
      return Object.assign({}, state, {
        lumpSum: action.payload,
        inputDirty: true,
      });
    case INVESTMENT_PROFILE_ADDED:
      return Object.assign({}, state, {
        investmentProfile: action.payload,
        inputDirty: true,
      });
    case CALCULATION_DONE:
      return Object.assign({}, state, {
        calculationResult: action.payload,
        inputDirty: false,
      });
    default:
      return state;
  }
}

export const store = Redux.createStore(
  counter,
  window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
);
