import {
  CALCULATION_DONE,
  PENSIONGOAL_CACULATOR,
  MONTHLY_SAVINGS_CACULATOR,
} from '../store.js';

export class CalculationService {
  START_REMOTE_CALL = 'START_REMOTE_CALL';
  END_REMOTE_CALL = 'END_REMOTE_CALL';

  constructor(store) {
    this.store = store;
    this.store.subscribe(this.watch.bind(this));
  }

  isMonthlySavingsCalculator() {
    return MONTHLY_SAVINGS_CACULATOR === this.store.getState().calculatorType;
  }

  watch() {
    const state = this.store.getState();
    if (!state.inputDirty) {
      return;
    }
    if (
      this.has('retirementAge') &&
      this.has('minpension') &&
      this.has('age') &&
      this.has('investmentProfile') &&
      this.has('lumpSum')
    ) {
      if (this.isMonthlySavingsCalculator()) {
        if (this.has('wishedPensionGoal')) {
          this.remoteCall();
        }
      }
    }
  }

  has(value) {
    return this.store.getState()[value] != null;
  }

  remoteCall() {
    fetch('./mock.json')
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        this.store.dispatch({ type: CALCULATION_DONE, payload: data });
      });
  }
}
